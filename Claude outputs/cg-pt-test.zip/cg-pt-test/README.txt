CG PERFORMANCE TRAINING - LOCAL TEST
====================================
This is a full copy of your website with the new contract changes, for testing on
your own computer. It does NOT touch your CG-PT folder, Netlify, your live site or Stripe.

START
  1. Open Terminal
  2. Type:   cd ~/Downloads/cg-pt-test
  3. Type:   python3 test-server.py
  Your browser opens on the packages page.

TEST
  - Press a package's buy button  ->  sign the contract  ->  fake checkout  ->  Pay (test)
  - Admin page: http://localhost:8000/admin.html   password: test
  - Phone: use the "On your phone" address shown in Terminal (same Wi-Fi).
    If your Mac asks to allow incoming connections for Python, click Allow.

STOP
  Click in Terminal and press Ctrl + C.

Test contracts are saved in test-submissions.json. Delete that file to start fresh.
