#!/usr/bin/env python3
"""
CG Performance Training - LOCAL TEST SERVER
Lets you test the contract, fake payment and admin page on your own computer.
Nothing here touches your live website, Netlify or Stripe.

Run:   python3 test-server.py
Then open http://localhost:8000 in your browser.  Stop with Ctrl+C.

- Signed contracts and payments are saved in test-submissions.json in this folder.
- Admin page password in test mode:  test
- Stripe is replaced with a fake checkout page, so no real money is taken.
"""
import http.server, json, os, re, socket, urllib.parse, uuid, webbrowser, threading
from datetime import datetime, timezone

PORT = 8000
ROOT = os.path.dirname(os.path.abspath(__file__))
SITE = os.path.join(ROOT, 'site')
DATA = os.path.join(ROOT, 'test-submissions.json')
PASSWORD = 'test'
FORMS = {'consent': 'photo-consent', 'enquiry': 'enquiry', 'contract': 'contract', 'payment': 'payment-confirmed'}

# Stripe payment link -> plan, so the fake checkout knows which thank-you page to go to
STRIPE = {
    '7sY6oJgHb1800rg7IB9Zm0f': 'foundation', '9B69AV9eJdUM5LAaUN9Zm0d': 'core',
    'aFa9AVaiN6sk8XM3sl9Zm0c': 'performance', '5kQcN776B2c40rg3sl9Zm0b': 'online',
    'aFa8wR62xbME2zo2oh9Zm0a': 'online-plus',
}

BANNER = ('<div style="position:fixed;top:0;left:0;right:0;z-index:99999;background:#f0b429;color:#0d1b2a;'
          'font:700 13px/1.2 sans-serif;text-align:center;padding:6px;letter-spacing:.05em;">'
          'LOCAL TEST MODE &mdash; nothing is sent to your live site or Stripe &middot; admin password: test</div>')


def load():
    try:
        with open(DATA) as f:
            return json.load(f)
    except Exception:
        return []


def save(subs):
    with open(DATA, 'w') as f:
        json.dump(subs, f, indent=2)


CHECKOUT = '''<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Fake checkout (test)</title></head>
<body style="font-family:sans-serif;background:#f6f9fc;display:grid;place-items:center;min-height:100vh;margin:0">
<div style="background:#fff;padding:2rem;border-radius:8px;box-shadow:0 2px 12px rgba(0,0,0,.1);max-width:380px;width:90%;text-align:center">
<p style="color:#c0392b;font-weight:700">TEST CHECKOUT &mdash; not real Stripe</p>
<h2 style="margin:.5rem 0">{plan}</h2>
<p>Email: <b>{email}</b><br>Contract ref: <b>{ref}</b></p>
<p><a href="/thank-you-{plan}.html" style="display:block;background:#635bff;color:#fff;padding:.9rem;border-radius:6px;text-decoration:none;font-weight:700">Pay (test &mdash; no money taken)</a></p>
<p><a href="/{plan}.html" style="color:#666">Cancel payment</a></p>
</div></body></html>'''


class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *a, **kw):
        super().__init__(*a, directory=SITE, **kw)

    def log_message(self, fmt, *args):
        pass

    def send_json(self, body, status=200):
        b = json.dumps(body).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(b)

    # Form submissions (what Netlify Forms does on the live site)
    def do_POST(self):
        n = int(self.headers.get('Content-Length', 0))
        data = {k: v[0] for k, v in urllib.parse.parse_qs(self.rfile.read(n).decode()).items()}
        if data.get('bot-field'):
            self.send_response(200); self.end_headers(); return
        data.pop('bot-field', None)
        subs = load()
        subs.append({'id': uuid.uuid4().hex, 'form': data.get('form-name'),
                     'created_at': datetime.now(timezone.utc).isoformat(), 'data': data})
        save(subs)
        print('  Saved a "%s" submission' % data.get('form-name'))
        self.send_response(200); self.end_headers(); self.wfile.write(b'ok')

    def do_DELETE(self):
        self.api()

    def do_GET(self):
        path = urllib.parse.urlparse(self.path).path
        if path.startswith('/api/consent-submissions'):
            return self.api()
        if path.startswith('/test-checkout/'):
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            plan = STRIPE.get(path.rsplit('/', 1)[-1], 'foundation')
            esc = lambda s: s.replace('&', '&amp;').replace('<', '&lt;')
            page = CHECKOUT.format(plan=plan, email=esc(q.get('prefilled_email', [''])[0]),
                                   ref=esc(q.get('client_reference_id', [''])[0]))
            b = page.encode()
            self.send_response(200); self.send_header('Content-Type', 'text/html; charset=utf-8'); self.end_headers()
            self.wfile.write(b); return
        if path == '/' :
            path = '/index.html'
        file = os.path.join(SITE, path.lstrip('/'))
        if path.endswith('.html') and os.path.isfile(file):
            with open(file, encoding='utf-8') as f:
                html = f.read()
            html = html.replace('https://buy.stripe.com/', '/test-checkout/')   # fake Stripe
            html = re.sub(r'<body([^>]*)>', lambda m: '<body' + m.group(1) + '>' + BANNER, html, count=1)
            b = html.encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Cache-Control', 'no-store')
            self.end_headers()
            self.wfile.write(b)
            return
        return super().do_GET()

    # What the Netlify function does on the live site, using the local test data
    def api(self):
        if self.headers.get('Authorization', '').replace('Bearer ', '') != PASSWORD:
            return self.send_json({'error': 'Incorrect password'}, 401)
        q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
        name = FORMS.get(q.get('form', ['consent'])[0])
        if not name:
            return self.send_json({'error': 'Unknown form'}, 400)
        subs = load()
        if self.command == 'DELETE':
            sid = q.get('id', [''])[0]
            save([s for s in subs if s['id'] != sid])
            return self.send_json({'deleted': sid})
        out = []
        for s in subs:
            if s['form'] == name:
                d = dict(s['data']); d.pop('form-name', None)
                out.append(dict(id=s['id'], created_at=s['created_at'], **d))
        return self.send_json({'submissions': out})


if __name__ == '__main__':
    url = 'http://localhost:%d' % PORT
    print('\nCG-PT local test server running at %s' % url)
    print('Try a package:  %s/packages.html' % url)
    print('Admin page:     %s/admin.html   (password: test)' % url)
    try:
        sk = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); sk.connect(('10.255.255.255', 1)); ip = sk.getsockname()[0]; sk.close()
        print('On your phone (same Wi-Fi):  http://%s:%d/packages.html' % (ip, PORT))
    except Exception:
        pass
    print('Press Ctrl+C to stop.\n')
    threading.Timer(1.0, lambda: webbrowser.open(url + '/packages.html')).start()
    try:
        http.server.ThreadingHTTPServer(('0.0.0.0', PORT), Handler).serve_forever()
    except KeyboardInterrupt:
        print('\nStopped.')
